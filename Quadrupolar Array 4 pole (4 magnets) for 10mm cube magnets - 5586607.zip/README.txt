Quadrupolar Array 4 pole (4 magnets) for 10mm cube magnets by OmegaZZ on Thingiverse: https://www.thingiverse.com/thing:5586607

Summary:
This magnet array was designed for 9,5mm cube magnets!If your magnets are slightly bigger just upscale your print a bit to fit your size.You can arrange the magnets facing all the same direction or in a north - south pole alternating pattern like shown on the picture.