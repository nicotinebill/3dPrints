Test Cylinder by sleepingowl007 on Thingiverse: https://www.thingiverse.com/thing:824730

Summary:
Just a test cylinder. It is 0.75 cm in radius and 1 cm tall