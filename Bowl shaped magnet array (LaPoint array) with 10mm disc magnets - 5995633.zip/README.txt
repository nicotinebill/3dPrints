Bowl shaped magnet array (LaPoint array) with 10mm disc magnets by OmegaZZ on Thingiverse: https://www.thingiverse.com/thing:5995633

Summary:
This array uses 40 pieces of Ø10x6mm neodymium disc magnets.