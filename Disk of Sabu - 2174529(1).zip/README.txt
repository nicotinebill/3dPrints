Disk of Sabu by Franck2Monaco on Thingiverse: https://www.thingiverse.com/thing:2174529

Summary:
This thing was made with Tinkercad. Edit it online https://www.tinkercad.com/things/7zlh77A74zY